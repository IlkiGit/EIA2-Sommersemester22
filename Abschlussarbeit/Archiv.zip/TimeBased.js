"use strict";
var FieldSimulator;
(function (FieldSimulator) {
    class TimeBased {
        value;
        constructor() {
            this.value = 0;
        }
    }
    FieldSimulator.TimeBased = TimeBased;
})(FieldSimulator || (FieldSimulator = {}));
//# sourceMappingURL=TimeBased.js.map