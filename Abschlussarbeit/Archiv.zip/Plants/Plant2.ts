namespace FieldSimulator {
    export class Plant2 extends Plant {
        name: string = "Plant2";
        waterDrainage: number = 0.5;
        fertilizerDemand: number = 0.5;
        pestsProbability: number = 1;
        growthSpeed: number = 1;
        
    }
}