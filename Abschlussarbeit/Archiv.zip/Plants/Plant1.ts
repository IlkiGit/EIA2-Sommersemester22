namespace FieldSimulator {
    export class Plant1 extends Plant {
        name: string = "Plant1";
        waterDrainage: number = 0.5;
        fertilizerDemand: number = 0;
        pestsProbability: number = 0;
        growthSpeed: number = 1;
        
    }
}