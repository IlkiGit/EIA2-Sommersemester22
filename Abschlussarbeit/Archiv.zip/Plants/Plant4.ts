namespace FieldSimulator {
    export class Plant4 extends Plant {
        name: string = "Plant4";
        waterDrainage: number = 0.5;
        fertilizerDemand: number = 2;
        pestsProbability: number = 2;
        growthSpeed: number = 1;
        
    }
}