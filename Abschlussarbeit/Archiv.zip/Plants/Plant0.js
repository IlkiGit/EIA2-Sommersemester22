"use strict";
var FieldSimulator;
(function (FieldSimulator) {
    class Plant0 extends FieldSimulator.Plant {
        name = "Plant0";
        waterDrainage = 0;
        fertilizerDemand = 0;
        pestsProbability = 0;
        growthSpeed = 0;
    }
    FieldSimulator.Plant0 = Plant0;
})(FieldSimulator || (FieldSimulator = {}));
//# sourceMappingURL=Plant0.js.map