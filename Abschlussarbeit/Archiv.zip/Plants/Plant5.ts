namespace FieldSimulator {
    export class Plant5 extends Plant {
        name: string = "Plant5";
        waterDrainage: number = 2;
        fertilizerDemand: number = 2;
        pestsProbability: number = 2;
        growthSpeed: number = 1;
        
    }
}