namespace FieldSimulator {
    export class Plant3 extends Plant {
        name: string = "Plant3";
        waterDrainage: number = 1;
        fertilizerDemand: number = 0.5;
        pestsProbability: number = 2;
        growthSpeed: number = 1;
        
    }
}